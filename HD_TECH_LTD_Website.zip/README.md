# HD TECH LTD Website

Responsive static website for HD TECH LTD.

## Preview
Open `index.html` in a browser.

## Publish
Upload the files to GitHub Pages, Netlify, Vercel, Cloudflare Pages, or any standard web host.

## Before launch
Review project maturity wording, add company registration details if desired, and add Privacy/Cookie pages if analytics or tracking are introduced.
